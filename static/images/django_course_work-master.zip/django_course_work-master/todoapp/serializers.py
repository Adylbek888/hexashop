from rest_framework import serializers

class TaskSerializer(serializers.Serializer):
    # user = serializers.ForeignKey()
    title = serializers.CharField()
    description = serializers.CharField()
    complete = serializers.BooleanField()
    created = serializers.DateTimeField()