This is Todolist app for note the tasks.
 I'm especially use Class Based views, Register, user authentication, login and logout, CRUD system, You can Add, view, update and delete task.
Firstly you need install all modules which written in requirements.txt
I use Django-Rest-Framework for work with API(application programming interface ). And it have a JavaScript for load data as json.
 If you want get api of my app, you may clikc Get API button and then see the console in browser!
 After you have completed your planned tasks, you must clikc complete and then the circle will appear in yellow color.
