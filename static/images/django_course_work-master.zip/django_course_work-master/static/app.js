async function get_api() {
    let req = await fetch("/api/v1/tasks");
    let res = await req.json();
    console.log(res);
}